XML-Schema Team

Team members
Michael Conrads - 03618153
Andreas Eichner - 03622206
Emiliyana Kalinova - 03644465
Ha Ngan Nguyen - 03644399
Son Nguyen - 03622000


1. For windows: Run basexhttp.bat in Mancala/basex/bin
1. For *nix: Run ./basexhttp in Mancala/basex/bin

2. Open Firefox (only works in Firefox at the moment), enter http://localhost:8984/db/initgameindex
3. Enjoy!
